<?php

$rg = "/f|g|j|p|q|y/";
$text = "we are ha.";
if ( preg_match($rg, $text) ) {
    $text1 =" have f,g,j,p,q,y";    
} else {
    $text2 = " does not have";
}
echo $text1.$text2;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// $text = 'Sample textfdsafdsafdsafdsafdsafdafdsafdsafdsafdsafdsafdsafdafsdf';
// $font_size = 32; // Font size is in pixels.
// $font_file = 'Arialbd.ttf'; // This is the path to your font file.

// // Determine image width and height, 10 pixels are added for 5 pixels padding:
// $box   = imagettfbbox($font_size, 0, $font_file, $text); 
// if( !$box ) 
// 	return false; 
// $min_x = min( array($box[0], $box[2], $box[4], $box[6]) ); 
// $max_x = max( array($box[0], $box[2], $box[4], $box[6]) ); 
// $min_y = min( array($box[1], $box[3], $box[5], $box[7]) ); 
// $max_y = max( array($box[1], $box[3], $box[5], $box[7]) ); 
// $width  = ( $max_x - $min_x ); 
// $height = ( $max_y - $min_y ); 

// var_dump($width);
// var_dump($height);
// // Create image:
// $image = imagecreatetruecolor($image_width, $image_height);

// // Allocate text and background colors (RGB format):
// $text_color = imagecolorallocate($image, 255, 255, 255);
// $bg_color = imagecolorallocate($image, 127, 127, 127);

// // Fill image:
// imagefill($image, 0, 0, $bg_color);

// // Fix starting x and y coordinates for the text:
// $x = 5; // Padding of 5 pixels.
// $y = $image_height - 5; // So that the text is vertically centered.

// // Add TrueType text to image:
// imagettftext($image, $font_size, 0, $x, $y, $text_color, $font_file, $text);

// Generate and send image to browser:
// header('Content-type: image/png');
// $filename = "image.png";
// imagepng($image, $filename);

// Destroy image in memory to free-up resources:


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// $dest = imagecreatefrompng('https://cdn.jsdelivr.net/emojione/assets/4.5/png/32/1f60f.png');
// $src = imagecreatefrompng('image.png');

// $w1 = imagesx($dest);
// $w2 = imagesx($src);
// $h1 = imagesy($dest);
// $h2 = imagesy($src);

// $newWidth = $w1 + $w2;
// $newHeight = $h1 > $h2 ? $h1 : $h2;
// $newImage = imagecreatetruecolor($newWidth, $newHeight);
// $bg_color = imagecolorallocate($newImage, 255, 255, 255);
// imagefill($newImage, 0, 0, $bg_color);


// imagecopyresampled($newImage, $dest, 0, 0, 0, 0, $w1, $h1, $w1, $h1);
// imagecopyresampled($newImage, $src, $w1, 0, 0, 0, $w2, $h2, $w2, $h2);

// header('Content-Type: image/png');
// $filename = "image_output.png";
// imagepng($newImage, $filename);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
?>